let username;
let password;
function storedata() {
            //alert("arpit");
     username=document.getElementById("user12").value;
     password=document.getElementById("pass12").value;
    
    //alert(username+" "+password);
}

function getData()
{
	let username1=document.getElementById("user23").value;
    let password1=document.getElementById("pass23").value;
    //alert(username1+" "+password1);
	//alert(username+" "+password);    
	if(username==username1 && password==password1)
	{
		alert("welcome!");
	}
}
